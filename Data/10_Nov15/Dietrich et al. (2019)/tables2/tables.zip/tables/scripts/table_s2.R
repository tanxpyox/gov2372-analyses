##################################################################
# Description: Replicates Table S2 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: raw_results_scaled.csv                                   #
# Packages: xtable_1.8-2                                         #
# Output: table_s2.html                                          #
# Run Time: 0.4431071 secs                                       #
##################################################################

require(xtable)

setwd('/Users/brycedietrich/Downloads/tables/')

justices<-read.csv('data/raw_results_scaled.csv',as.is=TRUE)
my_justices<-unique(justices$speaker_id)
my_justices<-my_justices[my_justices!="unidentified_justice"]

table_results<-c(0,0,0,0)
for(my_justice in my_justices){
  print(my_justice)
  temp_justices<-justices[justices$speaker_id==my_justice,]
  temp_justices$pitch_diff<-temp_justices$petitioner_pitch-temp_justices$respondent_pitch
  temp_justices<-temp_justices[is.na(temp_justices$pitch_diff)==FALSE,]
  table_results<-rbind(table_results,c(c(my_justice,mean(temp_justices[,'pitch_diff']),sd(temp_justices[,'pitch_diff']),NROW(temp_justices))))
}
table_results<-table_results[-1,]

colnames(table_results)<-c('justice','pitch_mean','pitch_sd','cases')
table_results<-data.frame(table_results,stringsAsFactors=FALSE)
table_results$pitch_mean<-as.numeric(table_results$pitch_mean)
table_results$pitch_sd<-as.numeric(table_results$pitch_sd)
table_results$cases<-as.numeric(table_results$cases)
table_results<-table_results[order(table_results$pitch_mean,decreasing = TRUE),]
table_results$pitch_mean<-round(table_results$pitch_mean,2)
table_results$pitch_sd<-round(table_results$pitch_sd,2)
table_results<-table_results[is.na(table_results$pitch_mean)==FALSE,]
table_results<-rbind(table_results,c('averages',round(c(mean(table_results$pitch_mean),mean(table_results$pitch_sd,na.rm=TRUE),mean(table_results$cases)),2)))
table_results[table_results$justice=="clarence_thomas","pitch_sd"]<-'-'

print(xtable(table_results),type='html',file='output/table_s2.html',include.rownames=FALSE)