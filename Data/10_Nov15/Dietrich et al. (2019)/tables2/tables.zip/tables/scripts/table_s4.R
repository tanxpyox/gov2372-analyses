##################################################################
# Description: Replicates Table S4 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: case_outcome_data.csv                                    #
#       small_cases.csv                                          #
#       justice_outcome_data.csv                                 #
#       small_justices.csv                                       #
# Packages: caret_6.0-80                                         #
#           ggplot2_2.2.1                                        #
#           lattice_0.20-35                                      #
#           lme4_1.1-17                                          #
#           Matrix_1.2-14                                        #
#           xtable_1.8-2                                         #
# Output: table_s4_cases.html                                    #
#         table_s4_justices.html                                 #
# Run Time: 2.556909 mins                                        #
##################################################################

require(caret)
require(lme4)
require(xtable)

setwd('/Users/brycedietrich/Downloads/tables/')

########CASE OUTCOMES########
#load data
case_outcome<-read.csv("data/case_outcome_data.csv",as.is=TRUE)
cases<-read.csv("data/small_cases.csv",as.is=TRUE)

table_results<-c(0,0,0,0)

base_year<-1998
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat1998<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))


base_year<-1999
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat1999<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2000
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2000<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.61,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.61,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.61,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2001
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2001<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2002
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2002<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2003
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2003<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.53,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.53,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.53,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2004
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2004<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2005
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>=cases$term&cases$naturalCourt%in%unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2005<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.58,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.58,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.58,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2006
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2006<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2007
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2007<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2008
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2008<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2009
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>=cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2009<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.66,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.66,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.66,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2010
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>=cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2010<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.55,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.55,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.55,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2011
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2011<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.58,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.58,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.58,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

base_year<-2012
test_sc<-cases[cases$term==base_year,]
training_sc<-cases[base_year>cases$term&cases$naturalCourt==unique(cases[cases$term==base_year,"naturalCourt"]),]

mod1<-glm(petitioner_vote~pitch_diff,data=training_sc,family=binomial("logit"))

test.probs<-predict(mod1,test_sc,type="response")

mat2012<-confusionMatrix(factor(test_sc$petitioner_vote),factor(ifelse(test.probs>.50,1,0)))

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,case_outcome[case_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(case_outcome[case_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
  
}

table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))
table_results<-table_results[-1,]
colnames(table_results)<-c("pitch_correct","pitch_total","fantasy_correct","fantasy_total")

my_stat<-NULL
my_p<-NULL
for(i in 1:NROW(table_results)){
  my_p<-c(my_p,prop.test(unlist(table_results[i,c("pitch_correct","fantasy_correct")]),unlist(table_results[i,c("pitch_total","fantasy_total")]))$p.value)
  my_stat<-c(my_stat,prop.test(unlist(table_results[i,c("pitch_correct","fantasy_correct")]),unlist(table_results[i,c("pitch_total","fantasy_total")]))$statistic)
}
table_results<-cbind(1998:2012,table_results,my_stat,my_p)
colnames(table_results)[6:7]<-c("chi_sq","p")
colnames(table_results)[1]<-"term"

table_results<-rbind(table_results,c(9999,sum(table_results[,'pitch_correct']),sum(table_results[,'pitch_total']),sum(table_results[,'fantasy_correct']),sum(table_results[,'fantasy_total']),as.numeric(prop.test(c(sum(table_results[,'pitch_correct']),sum(table_results[,'fantasy_correct'])),c(sum(table_results[,'pitch_total']),sum(table_results[,'fantasy_total'])))$statistic),prop.test(c(sum(table_results[,'pitch_correct']),sum(table_results[,'fantasy_correct'])),c(sum(table_results[,'pitch_total']),sum(table_results[,'fantasy_total'])))$p.value))
table_results<-data.frame(table_results)
table_results$pitch_percent<-round((table_results$pitch_correct/table_results$pitch_total)*100,2)
table_results$fantasy_percent<-round((table_results$fantasy_correct/table_results$fantasy_total)*100,2)
table_results[NROW(table_results),'term']<-'total'
table_results$term_label<-paste(table_results$term," (n = ",table_results$pitch_total,")",sep="")
table_results$chi_label<-paste(round(table_results$chi_sq,2),' (p < ',round(table_results$p,3),')',sep="")

print(xtable(table_results[,c('term_label','pitch_percent','fantasy_percent','chi_label')]),type='html',file='output/table_s4_cases.html',include.rownames=FALSE)

#####JUSTICE OUTCOMES#####
justice_outcome<-read.csv("data/justice_outcome_data.csv",as.is=TRUE)
sc<-read.csv("data/small_justices.csv",as.is=TRUE)

#####JUSTICES
table_results<-c(0,0,0,0)

#1998
base_year<-1998
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#1999
base_year<-1999
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#2000
base_year<-2000
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2001
base_year<-2001
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2002
base_year<-2002
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2003
base_year<-2003
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2004
base_year<-2004
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2005
base_year<-2005
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>=sc$term&sc$naturalCourt%in%unique(sc[sc$term==base_year,"naturalCourt"])[2],]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2006
base_year<-2006
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

###2007
base_year<-2007
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#2008
base_year<-2008
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#2009
base_year<-2009
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>=sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#2010
base_year<-2010
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>=sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#2011
base_year<-2011
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>=sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))

#2012
base_year<-2012
test_sc<-sc[sc$term==base_year,]
training_sc<-sc[base_year>sc$term&sc$naturalCourt==unique(sc[sc$term==base_year,"naturalCourt"]),]

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=training_sc,family=binomial)
test.probs<-predict(mod1,test_sc,type="response",re.form=NA)

my_correct<-NULL
for(i in 1:NROW(test_sc)){
  print(i)
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])==1){
    my_correct<-c(my_correct,justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],"correct"])
  }
  
  if(NROW(justice_outcome[justice_outcome$justice==test_sc[i,"justice"]&justice_outcome$docket==test_sc[i,"docketId"],])!=1){
    my_correct<-c(my_correct,NA)
  }
}
my_correct<-my_correct[is.na(test.probs)==FALSE]
table_results<-rbind(table_results,c(sum(diag(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table)),sum(confusionMatrix(factor(test_sc$petitioner_vote[is.na(my_correct)==FALSE]),factor(ifelse(test.probs[is.na(my_correct)==FALSE]>.50,1,0)))$table),table(my_correct)["True"],sum(table(my_correct))))
table_results<-table_results[-1,]
colnames(table_results)<-c("pitch_correct","pitch_total","fantasy_correct","fantasy_total")

my_stat<-NULL
my_p<-NULL
for(i in 1:NROW(table_results)){
  my_p<-c(my_p,prop.test(unlist(table_results[i,c("pitch_correct","fantasy_correct")]),unlist(table_results[i,c("pitch_total","fantasy_total")]))$p.value)
  my_stat<-c(my_stat,prop.test(unlist(table_results[i,c("pitch_correct","fantasy_correct")]),unlist(table_results[i,c("pitch_total","fantasy_total")]))$statistic)
}
table_results<-cbind(1998:2012,table_results,my_stat,my_p)
colnames(table_results)[6:7]<-c("chi_sq","p")
colnames(table_results)[1]<-"term"

table_results<-rbind(table_results,c(9999,sum(table_results[,'pitch_correct']),sum(table_results[,'pitch_total']),sum(table_results[,'fantasy_correct']),sum(table_results[,'fantasy_total']),as.numeric(prop.test(c(sum(table_results[,'pitch_correct']),sum(table_results[,'fantasy_correct'])),c(sum(table_results[,'pitch_total']),sum(table_results[,'fantasy_total'])))$statistic),prop.test(c(sum(table_results[,'pitch_correct']),sum(table_results[,'fantasy_correct'])),c(sum(table_results[,'pitch_total']),sum(table_results[,'fantasy_total'])))$p.value))
table_results<-data.frame(table_results)
table_results$pitch_percent<-round((table_results$pitch_correct/table_results$pitch_total)*100,2)
table_results$fantasy_percent<-round((table_results$fantasy_correct/table_results$fantasy_total)*100,2)
table_results[NROW(table_results),'term']<-'total'
table_results$term_label<-paste(table_results$term," (n = ",table_results$pitch_total,")",sep="")
table_results$chi_label<-paste(round(table_results$chi_sq,2),' (p < ',round(table_results$p,3),')',sep="")

print(xtable(table_results[,c('term_label','pitch_percent','fantasy_percent','chi_label')]),type='html',file='output/table_s4_justices.html',include.rownames=FALSE)