##################################################################
# Description: Replicates Table S7 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: justice_results.tab                                      #
# Packages: lme4_1.1-17                                          #
#           Matrix_1.2-14                                        #
#           xtable_1.8-2                                         #
# Output: table_s7_no_controls.html                              #
#         table_s7_with_dal.html                                 #
#         table_s7_with_harvard.html                             #
#         table_s7_with_liwc.html                                #
# Run Time: 17.61217 secs                                        #
##################################################################

require(lme4)
require(xtable)

setwd('/Users/brycedietrich/Downloads/tables/')

#### No Controls
sc<-read.table("data/justice_results.tab",header=TRUE,as.is=TRUE,sep="\t")

mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=sc,family=binomial)

base_matrix<-table(ifelse(predict(mod1,type="response",re.form=NA)>.50,"Test_Yes","Test_No"),ifelse(sc[,"petitioner_vote"]==1,"Actual_Yes","Actual_No"))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'petitioner'","model = 'respondent'")
colnames(table_results)<-c("actual = 'petitioner'","actual = 'respondent'")

print(xtable(table_results),type='html',file='output/table_s7_no_controls.html')

#### With Controls (DAL)
sc$petitioner_pos_words<-sc$petitioner_dal_pos
sc$petitioner_neg_words<-sc$petitioner_dal_neg
sc$respondent_pos_words<-sc$respondent_dal_pos
sc$respondent_neg_words<-sc$respondent_dal_neg

mod2<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(1|justiceName),data=sc,family=binomial)

base_matrix<-table(ifelse(predict(mod2,type="response",re.form=NA)>.50,"Test_Yes","Test_No"),ifelse(sc[names(residuals(mod2)),"petitioner_vote"]==1,"Actual_Yes","Actual_No"))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'petitioner'","model = 'respondent'")
colnames(table_results)<-c("actual = 'petitioner'","actual = 'respondent'")

print(xtable(table_results),type='html',file='output/table_s7_with_dal.html')

#### With Controls (Harvard-IV)
sc$petitioner_pos_words<-sc$petitioner_harvard_pos
sc$petitioner_neg_words<-sc$petitioner_harvard_neg
sc$respondent_pos_words<-sc$respondent_harvard_pos
sc$respondent_neg_words<-sc$respondent_harvard_neg

mod3<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(1|justiceName),data=sc,family=binomial)

base_matrix<-table(ifelse(predict(mod3,type="response",re.form=NA)>.50,"Test_Yes","Test_No"),ifelse(sc[names(residuals(mod3)),"petitioner_vote"]==1,"Actual_Yes","Actual_No"))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'petitioner'","model = 'respondent'")
colnames(table_results)<-c("actual = 'petitioner'","actual = 'respondent'")

print(xtable(table_results),type='html',file='output/table_s7_with_harvard.html')

#### With Controls (LIWC)
sc$petitioner_pos_words<-sc$petitioner_liwc_pos
sc$petitioner_neg_words<-sc$petitioner_liwc_neg
sc$respondent_pos_words<-sc$respondent_liwc_pos
sc$respondent_neg_words<-sc$respondent_liwc_neg

mod4<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(1|justiceName),data=sc,family=binomial)

base_matrix<-table(ifelse(predict(mod4,type="response",re.form=NA)>.50,"Test_Yes","Test_No"),ifelse(sc[names(residuals(mod4)),"petitioner_vote"]==1,"Actual_Yes","Actual_No"))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'petitioner'","model = 'respondent'")
colnames(table_results)<-c("actual = 'petitioner'","actual = 'respondent'")

print(xtable(table_results),type='html',file='output/table_s7_with_liwc.html')