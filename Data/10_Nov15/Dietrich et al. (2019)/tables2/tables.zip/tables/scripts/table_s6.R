##################################################################
# Description: Replicates Table S6 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: EmoJusticeRep.dta                                        #
#       justice_outcome_data.csv                                 #
#       martin_votes.csv                                         #
# Packages: foreign_0.8-70                                       #
#           xtable_1.8-2                                         #
# Output: table_s6_black.html                                    #
#         table_s6_katz.html                                     #
#         table_s6_martin.html                                   #
#         table_s6_intercept.html                                #
# Run Time: 10.9793 secs                                         #
##################################################################

require(foreign)
require(xtable)

setwd('/Users/brycedietrich/Downloads/tables/')

#### Black et al. (2011)
black<-read.dta('data/EmoJusticeRep.dta')

my_model<-glm(petVote~unpleasantDiff_totalWords+pleasantDiff_totalWords+questionDifference+justiceMQ+lowerConservative+lowerConXjusticeMQ+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat, data=black,family=binomial)
base_matrix<-table(ifelse(predict(my_model,type="response",re.form=NA)>.50,"Test_Yes","Test_No"),ifelse(black[,"petVote"]==1,"Actual_Yes","Actual_No"))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'petitioner'","model = 'respondent'")
colnames(table_results)<-c("actual = 'petitioner'","actual = 'respondent'")

print(xtable(table_results),type='html',file='output/table_s6_black.html')

#### Katz, Bommarito and Blackman (2014)
katz<-read.csv('data/justice_outcome_data.csv',as.is=TRUE)

base_matrix<-table(ifelse(katz$prediction==1,'Test_Yes','Test_No'),ifelse(katz$outcome==1,'Actual_Yes','Actual_No'))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'reverse'","model = 'no reverse'")
colnames(table_results)<-c("actual = 'reverse'","actual = 'no reverse'")

print(xtable(table_results),type='html',file='output/table_s6_katz.html')

#### Martin et al. (2004)
martin<-read.csv('data/martin_votes.csv',as.is=TRUE)

names(martin)[3]<-'prediction'
names(martin)[4]<-'outcome'
base_matrix<-table(ifelse(martin$prediction=='reverse','Test_Yes','Test_No'),ifelse(martin$outcome=='reverse','Actual_Yes','Actual_No'))
results_matrix<-matrix(0,2,2)
rownames(results_matrix)<-c("Test_Yes","Test_No")
colnames(results_matrix)<-c("Actual_Yes","Actual_No")
results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
fnr<-1-tpr
tnr<-1-fpr

table_results<-matrix(c(paste('tpr = ',round(tpr,2),sep=''),paste('fnr = ',round(fnr,2),sep=''),paste('fpr = ',round(fpr,2),sep=''), paste('tnr = ',round(tnr,2),sep='')),nrow=2)
rownames(table_results)<-c("model = 'reverse'","model = 'no reverse'")
colnames(table_results)<-c("actual = 'reverse'","actual = 'no reverse'")

print(xtable(table_results),type='html',file='output/table_s6_martin.html')

#### "Petitioner Always Wins"
table_results<-matrix(c(paste('tpr = ',1,sep=''),paste('fnr = ',0,sep=''),paste('fpr = ',1,sep=''), paste('tnr = ',0,sep='')),nrow=2)
rownames(table_results)<-c("model = 'petitioner'","model = 'respondent'")
colnames(table_results)<-c("actual = 'petitioner'","actual = 'respondent'")

print(xtable(table_results),type='html',file='output/table_s6_intercept.html')