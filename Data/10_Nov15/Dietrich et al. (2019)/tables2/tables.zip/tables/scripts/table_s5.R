##################################################################
# Description: Replicates Table S5 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: justice_outcome_data.csv                                 #
#       justice_results.tab                                      #
# Packages: stargazer_5.2.2                                      #
# Output: table_s5.html                                          #
# Run Time: 30.67156 secs                                        #
##################################################################

require(stargazer)

setwd('/Users/brycedietrich/Downloads/tables/')

#load justice_results
justice_outcome<-read.csv("data/justice_outcome_data.csv",as.is=TRUE)
sc<-read.table("data/justice_results.tab",header=TRUE,as.is=TRUE,sep="\t")
justice_outcome<-justice_outcome[justice_outcome$docket%in%sc$docketId,]
justice_outcome[justice_outcome == '-99' ] <- NA

for(i in 1:NROW(justice_outcome)){
  print(i)
  if(NROW(sc[sc$docketId==justice_outcome[i,'docket']&sc$justice==justice_outcome[i,'justice'],])>0){
    justice_outcome[i,'pitch_diff']<-sc[sc$docketId==justice_outcome[i,'docket']&sc$justice==justice_outcome[i,'justice'],'pitch_diff']
    justice_outcome[i,'petitioner_vote']<-sc[sc$docketId==justice_outcome[i,'docket']&sc$justice==justice_outcome[i,'justice'],'petitioner_vote']
  }
}

mod1<-glm(petitioner_vote~pitch_diff+law_type+lc_disposition+issue+issue_area+month_argument+month_decision+petitioner+petitioner_dk+respondent+respondent_dk+cert_reason+court_direction_issue_mean+court_direction_mean_10+lower_court_direction_issue_mean+current_court_direction_issue_mean+current_court_direction_circuit_origin_std+current_court_direction_issue_std+justice_direction_mean+justice_direction_mean_10+justice_direction_mean_z+diff_court_lc_direction+diff_court_lc_direction_abs+diff_court_lc_direction_abs_z+diff_justice_court_direction+diff_justice_court_direction_issue+diff_justice_court_direction_z+justice_agree_mean_10,data=justice_outcome,family=binomial)
stargazer(mod1,type='html',out='output/table_s5.html',intercept.bottom = FALSE, intercept.top = TRUE, dep.var.labels.include = FALSE, dep.var.caption = "")