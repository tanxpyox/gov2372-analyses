##################################################################
# Description: Replicates Table S1 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: raw_results.csv                                          #
# Packages: xtable_1.8-2                                         #
# Output: table_s1.html                                          #
# Run Time: 1.577978 secs                                        #
##################################################################

require(xtable)

setwd('/Users/brycedietrich/Downloads/tables/')

justices<-read.csv('data/raw_results.csv',as.is=TRUE)

justices$speaker_id<-tolower(justices$speaker_id)
justices[justices$speaker_id%in%c("samuel_a_alito_jr","samuel_alito","samuel_alito_jr"),"speaker_id"]<-"samuel_alito"
justices[justices$speaker_id%in%c("anthony_kennedy","anthony_m_kennedy"),"speaker_id"]<-"anthony_kennedy"
justices[justices$speaker_id%in%c("john_g_roberts","john_g_roberts_jr"),"speaker_id"]<-"john_g_roberts"
justices[justices$speaker_id%in%c("william_j_brennan","william_j_brennan_jr"),"speaker_id"]<-"william_j_brennan"
justices[justices$speaker_id%in%c("lewis_f_powell","lewis_f_powell_jr"),"speaker_id"]<-"lewis_f_powell"
my_justices<-unique(justices$speaker_id)
my_justices<-my_justices[my_justices!='unidentified_justice']

table_results<-rep(0,6)
for(my_justice in my_justices){
  temp_justices<-justices[justices$speaker_id==my_justice,]
  table_results<-rbind(table_results,c(my_justice,mean(temp_justices$pitch_mean),sd(temp_justices$pitch_mean),NROW(temp_justices[temp_justices$question==1,]),NROW(temp_justices[temp_justices$question==0,]),NROW(temp_justices)))
}

table_results<-table_results[-1,]
colnames(table_results)<-c('justice','pitch_mean','pitch_sd','questions','non_questions','total')
table_results<-data.frame(table_results,stringsAsFactors=FALSE)
table_results$pitch_mean<-round(as.numeric(table_results$pitch_mean),2)
table_results$pitch_sd<-round(as.numeric(table_results$pitch_sd),2)
table_results$questions<-as.numeric(table_results$questions)
table_results$non_questions<-as.numeric(table_results$non_questions)
table_results$total<-as.numeric(table_results$total)
table_results<-table_results[order(table_results$pitch_mean,decreasing = TRUE),]
table_results<-rbind(table_results,c("averages",round(colMeans(table_results[,c('pitch_mean','pitch_sd')]),2),round(colMeans(table_results[,c('questions','non_questions','total')]))))

print(xtable(table_results),type='html',file='output/table_s1.html',include.rownames=FALSE)