##################################################################
# Description: Replicates Table S9 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: sc_justice_questions.csv                                 #
#       sc_justice_statements.csv                                #
# Packages: lme4_1.1-17                                          #
#           Matrix_1.2-14                                        #
#           stargazer_5.2.2                                      #
# Output: table_s9_questions.html                                #
#         table_s9_non_questions.html                            #
#         table_s9_both.html                                     #
#         table_s9_both_with_controls.html                       #
# Run Time: 21.09376 secs                                        #
##################################################################

require(lme4)
require(stargazer)

setwd('/Users/brycedietrich/Downloads/tables/')

#load justice_results
sc_questions<-read.csv("data/sc_justice_questions.csv",as.is=TRUE)
sc_statements<-read.csv("data/sc_justice_statements.csv",as.is=TRUE)
sc_both<-rbind(sc_questions,sc_statements)

### Questions
mod1<-glmer(petitioner_vote~petitioner_pitch+(1|justiceName),data=sc_questions,family=binomial)
mod2<-glmer(petitioner_vote~respondent_pitch+(1|justiceName),data=sc_questions,family=binomial)
mod3<-glmer(petitioner_vote~petitioner_pitch+respondent_pitch+(1|justiceName),data=sc_questions,family=binomial)

stargazer(mod1,mod2,mod3,type='html',out='output/table_s9_questions.html',intercept.bottom = FALSE, intercept.top = TRUE, omit.stat = c('bic'), dep.var.labels.include = FALSE, dep.var.caption = "", column.labels = c('petitioner<br>only','respondent<br>only','petitioner<br>and<br>respondent'))

### Non-Questions
mod4<-glmer(petitioner_vote~petitioner_pitch+(1|justiceName),data=sc_statements,family=binomial)
mod5<-glmer(petitioner_vote~respondent_pitch+(1|justiceName),data=sc_statements,family=binomial)
mod6<-glmer(petitioner_vote~petitioner_pitch+respondent_pitch+(1|justiceName),data=sc_statements,family=binomial)

stargazer(mod4,mod5,mod6,type='html',out='output/table_s9_non_questions.html',intercept.bottom = FALSE, intercept.top = TRUE, omit.stat = c('bic'), dep.var.labels.include = FALSE, dep.var.caption = "", column.labels = c('petitioner<br>only','respondent<br>only','petitioner<br>and<br>respondent'))

### Both
mod7<-glmer(petitioner_vote~petitioner_pitch+(1|justiceName),data=sc_both,family=binomial)
mod8<-glmer(petitioner_vote~respondent_pitch+(1|justiceName),data=sc_both,family=binomial)
mod9<-glmer(petitioner_vote~petitioner_pitch+respondent_pitch+(1|justiceName),data=sc_both,family=binomial)

stargazer(mod7,mod8,mod9,type='html',out='output/table_s9_both.html',intercept.bottom = FALSE, intercept.top = TRUE, omit.stat = c('bic'), dep.var.labels.include = FALSE, dep.var.caption = "", column.labels = c('petitioner<br>only','respondent<br>only','petitioner<br>and<br>respondent'))

### Both with Controls
mod10<-glmer(petitioner_vote~petitioner_pitch+liberal_petitioner*post_med+(1|justiceName),data=sc_both,family=binomial)
mod11<-glmer(petitioner_vote~respondent_pitch+liberal_petitioner*post_med+(1|justiceName),data=sc_both,family=binomial)
mod12<-glmer(petitioner_vote~petitioner_pitch+respondent_pitch+liberal_petitioner*post_med+(1|justiceName),data=sc_both,family=binomial)

stargazer(mod10,mod11,mod12,type='html',out='output/table_s9_both_with_controls.html',intercept.bottom = FALSE, intercept.top = TRUE, omit.stat = c('bic'), dep.var.labels.include = FALSE, dep.var.caption = "", column.labels = c('petitioner<br>only','respondent<br>only','petitioner<br>and<br>respondent'))