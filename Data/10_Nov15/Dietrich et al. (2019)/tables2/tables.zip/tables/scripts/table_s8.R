##################################################################
# Description: Replicates Table S8 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: justice_results.tab                                      #
# Packages: lme4_1.1-17                                          #
#           Matrix_1.2-14                                        #
#           stargazer_5.2.2                                      #
# Output: table_s8.html                                          #
# Run Time: 24.15427 secs                                        #
##################################################################

require(lme4)
require(stargazer)

setwd('/Users/brycedietrich/Downloads/tables/')

#load justice_results
sc<-read.table("data/justice_results.tab",header=TRUE,as.is=TRUE,sep="\t")

#pitch only (Table S8, Model 1)
mod1_no_intercept<-glm(petitioner_vote~pitch_diff,data=sc,family=binomial)
mod1<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=sc,family=binomial)

#dal model (Table S8, Model 2)
sc$petitioner_pos_words<-sc$petitioner_dal_pos
sc$petitioner_neg_words<-sc$petitioner_dal_neg
sc$respondent_pos_words<-sc$respondent_dal_pos
sc$respondent_neg_words<-sc$respondent_dal_neg

#does not converge...number of questions directed at petitioner/respondent and number of words directed at petitioner/respondent highly correlated (0.73)
#reviewer suggested we add the word count variables
mod2_no_intercept<-glm(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+I(petitioner_wc/100)+I(respondent_wc/100),data=sc,family=binomial)
mod2<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+I(petitioner_wc/100)+I(respondent_wc/100)+(1|justiceName),data=sc,family=binomial)

#harvard model (Table S8, Model 3)
sc$petitioner_pos_words<-sc$petitioner_harvard_pos
sc$petitioner_neg_words<-sc$petitioner_harvard_neg
sc$respondent_pos_words<-sc$respondent_harvard_pos
sc$respondent_neg_words<-sc$respondent_harvard_neg

#does not converge...number of questions directed at petitioner/respondent and number of words directed at petitioner/respondent highly correlated (0.73)
#reviewer suggested we add the word count variables
mod3_no_intercept<-glm(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+I(petitioner_wc/100)+I(respondent_wc/100),data=sc,family=binomial)
mod3<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+I(petitioner_wc/100)+I(respondent_wc/100)+(1|justiceName),data=sc,family=binomial)

#liwc model  (Table S8, Model 4)
sc$petitioner_pos_words<-sc$petitioner_liwc_pos
sc$petitioner_neg_words<-sc$petitioner_liwc_neg
sc$respondent_pos_words<-sc$respondent_liwc_pos
sc$respondent_neg_words<-sc$respondent_liwc_neg

#does not converge...number of questions directed at petitioner/respondent and number of words directed at petitioner/respondent highly correlated (0.73)
#reviewer suggested we add the word count variables
mod4_no_intercept<-glm(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+I(petitioner_wc/100)+I(respondent_wc/100),data=sc,family=binomial)
mod4<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+I(petitioner_wc/100)+I(respondent_wc/100)+(1|justiceName),data=sc,family=binomial)

mod1_re<-as.data.frame(VarCorr(mod1))
mod2_re<-as.data.frame(VarCorr(mod2))
mod3_re<-as.data.frame(VarCorr(mod3))
mod4_re<-as.data.frame(VarCorr(mod4))

intercept_re_var<-c(round(mod1_re[mod1_re$var1=="(Intercept)"&is.na(mod1_re$var2),'vcov'],2),round(mod2_re[mod2_re$var1=="(Intercept)"&is.na(mod2_re$var2),'vcov'],2),round(mod3_re[mod3_re$var1=="(Intercept)"&is.na(mod3_re$var2),'vcov'],2),round(mod4_re[mod4_re$var1=="(Intercept)"&is.na(mod4_re$var2),'vcov'],2))
intercept_re_sd<-c(round(mod1_re[mod1_re$var1=="(Intercept)"&is.na(mod1_re$var2),'sdcor'],2),round(mod2_re[mod2_re$var1=="(Intercept)"&is.na(mod2_re$var2),'sdcor'],2),round(mod3_re[mod3_re$var1=="(Intercept)"&is.na(mod3_re$var2),'sdcor'],2),round(mod4_re[mod4_re$var1=="(Intercept)"&is.na(mod4_re$var2),'sdcor'],2))

get_stars<-function(p_value){
  stars<-''
  if(p_value>0&0.01>=p_value){
    stars<-'***'
  }
  if(p_value>0.01&0.05>=p_value){
    stars<-'**'
  }
  if(p_value>0.05&0.10>=p_value){
    stars<-'*'
  }
  return(stars)
}

intercept_re_var<-c(paste(intercept_re_var[1],'^{',get_stars(anova(mod1,mod1_no_intercept,test="Chisq")[2,8]),"}",sep=''),
                    paste(intercept_re_var[2],'^{',get_stars(anova(mod2,mod2_no_intercept,test="Chisq")[2,8]),"}",sep=''),
                    paste(intercept_re_var[2],'^{',get_stars(anova(mod3,mod3_no_intercept,test="Chisq")[2,8]),"}",sep=''),
                    paste(intercept_re_var[4],'^{',get_stars(anova(mod4,mod4_no_intercept,test="Chisq")[2,8]),"}",sep='')
                    )

stargazer(mod1,mod2,mod3,mod4,type='html',
          out='output/table_s8.html',
          intercept.bottom = FALSE,
          intercept.top = TRUE,
          omit.stat = c('bic'),
          dep.var.labels.include = FALSE,
          dep.var.caption = "",
          column.labels = c('no controls','dal','harvard','liwc'),
          add.lines = list(c("Random Effects", "", "", "", "", ""),
                           c("", "", "", "", "", ""),
                           c("Intercept",intercept_re_var),
                           c("",intercept_re_sd),
                           c("", "", "", "", "", "")))