##################################################################
# Description: Replicates Table S3 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 6/7/2018                                                 #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"              #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: justice_results.tab                                      #
# Packages: lme4_1.1-17                                          #
#           Matrix_1.2-14                                        #
#           stargazer_5.2.2                                      #
# Output: table_s3.html                                          #
# Run Time: 37.72607 secs                                        #
##################################################################

require(lme4)
require(stargazer)

setwd('/Users/brycedietrich/Downloads/tables/')

#load justice_results
sc<-read.table("data/justice_results.tab",header=TRUE,as.is=TRUE,sep="\t")

#pitch only (Table S3, Model 1)
mod1_no_intercept<-glm(petitioner_vote~pitch_diff,data=sc,family=binomial)
mod1_intercept_only<-glmer(petitioner_vote~pitch_diff+(1|justiceName),data=sc,family=binomial)
mod1<-glmer(petitioner_vote~pitch_diff+(pitch_diff|justiceName),data=sc,family=binomial)
pred_mod1<-sum(diag(table(ifelse(predict(mod1,type="response")>.50,1,0),sc[names(residuals(mod1)),"petitioner_vote"])))/length(residuals(mod1))

#dal model (Table S3, Model 2)
sc$petitioner_pos_words<-sc$petitioner_dal_pos
sc$petitioner_neg_words<-sc$petitioner_dal_neg
sc$respondent_pos_words<-sc$respondent_dal_pos
sc$respondent_neg_words<-sc$respondent_dal_neg

mod2_no_intercept<-glm(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat,data=sc,family=binomial)
mod2_intercept_only<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(1|justiceName),data=sc,family=binomial)
mod2<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(pitch_diff|justiceName),data=sc,family=binomial)
pred_mod2<-sum(diag(table(ifelse(predict(mod2,type="response")>.50,1,0),sc[names(residuals(mod2)),"petitioner_vote"])))/length(residuals(mod2))
#the model does not converge. Problematic variables are two of the Black et al. controls: petNumStat and respNumStat
#when dropped from the model coefficient for pitch difference goes from -0.205511 to -0.208839 and standard error goes from 0.049334 to 0.048965
#when petNumStat and respNumStat are normalized using sc$petNumStat_norm<-(sc$petNumStat-mean(sc$petNumStat,na.rm=TRUE))/sd(sc$petNumStat,na.rm=TRUE) and sc$respNumStat_norm<-(sc$respNumStat-mean(sc$respNumStat,na.rm=TRUE))/sd(sc$respNumStat,na.rm=TRUE) coefficent for pitch difference goes from -0.205511 to -0.205518 and standard error goes from 0.049334 to 0.049334
#we report results for the model that did not converge to be consistent with Black et al.

#harvard model (Table S3, Model 3)
sc$petitioner_pos_words<-sc$petitioner_harvard_pos
sc$petitioner_neg_words<-sc$petitioner_harvard_neg
sc$respondent_pos_words<-sc$respondent_harvard_pos
sc$respondent_neg_words<-sc$respondent_harvard_neg

mod3_no_intercept<-glm(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat,data=sc,family=binomial)
mod3_intercept_only<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(1|justiceName),data=sc,family=binomial)
mod3<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(pitch_diff|justiceName),data=sc,family=binomial)
pred_mod3<-sum(diag(table(ifelse(predict(mod3,type="response")>.50,1,0),sc[names(residuals(mod3)),"petitioner_vote"])))/length(residuals(mod3))

#liwc model (Table 1, Model 5)
sc$petitioner_pos_words<-sc$petitioner_liwc_pos
sc$petitioner_neg_words<-sc$petitioner_liwc_neg
sc$respondent_pos_words<-sc$respondent_liwc_pos
sc$respondent_neg_words<-sc$respondent_liwc_neg

mod4_no_intercept<-glm(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat,data=sc,family=binomial)
mod4_intercept_only<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(1|justiceName),data=sc,family=binomial)
mod4<-glmer(petitioner_vote~pitch_diff+I((petitioner_neg_words/petitioner_wc)-(respondent_neg_words/respondent_wc))+I((petitioner_pos_words/petitioner_wc)-(respondent_pos_words/respondent_wc))+I(petitioner_count-respondent_count)+lagged_ideology+conservative_lc+I(lagged_ideology*conservative_lc)+sgpetac+sgrespac+petac+respac+petNumStat+respNumStat+(pitch_diff|justiceName),data=sc,family=binomial)
pred_mod4<-sum(diag(table(ifelse(predict(mod4,type="response")>.50,1,0),sc[names(residuals(mod4)),"petitioner_vote"])))/length(residuals(mod4))
#the model does not converge. Problematic variables are two of the Black et al. controls: petNumStat and respNumStat
#when dropped from the model coefficient for pitch difference goes from -0.205650 to -0.209007 and standard error goes from 0.049408 to 0.049039
#when petNumStat and respNumStat are normalized using sc$petNumStat_norm<-(sc$petNumStat-mean(sc$petNumStat,na.rm=TRUE))/sd(sc$petNumStat,na.rm=TRUE) and sc$respNumStat_norm<-(sc$respNumStat-mean(sc$respNumStat,na.rm=TRUE))/sd(sc$respNumStat,na.rm=TRUE) coefficent for pitch difference goes from -0.205650 to -0.205654 and standard error goes from 0.049408 to 0.049408
#we report results for the model that did not converge to be consistent with Black et al.

mod1_re<-as.data.frame(VarCorr(mod1))
mod2_re<-as.data.frame(VarCorr(mod2))
mod3_re<-as.data.frame(VarCorr(mod3))
mod4_re<-as.data.frame(VarCorr(mod4))

intercept_re_var<-c(round(mod1_re[mod1_re$var1=="(Intercept)"&is.na(mod1_re$var2),'vcov'],2),round(mod2_re[mod2_re$var1=="(Intercept)"&is.na(mod2_re$var2),'vcov'],2),round(mod3_re[mod3_re$var1=="(Intercept)"&is.na(mod3_re$var2),'vcov'],2),round(mod4_re[mod4_re$var1=="(Intercept)"&is.na(mod4_re$var2),'vcov'],2))
intercept_re_sd<-c(round(mod1_re[mod1_re$var1=="(Intercept)"&is.na(mod1_re$var2),'sdcor'],2),round(mod2_re[mod2_re$var1=="(Intercept)"&is.na(mod2_re$var2),'sdcor'],2),round(mod3_re[mod3_re$var1=="(Intercept)"&is.na(mod3_re$var2),'sdcor'],2),round(mod4_re[mod4_re$var1=="(Intercept)"&is.na(mod4_re$var2),'sdcor'],2))

get_stars<-function(p_value){
  stars<-''
  if(p_value>0&0.01>=p_value){
    stars<-'***'
  }
  if(p_value>0.01&0.05>=p_value){
    stars<-'**'
  }
  if(p_value>0.05&0.10>=p_value){
    stars<-'*'
  }
  return(stars)
}

intercept_re_var<-c(paste(intercept_re_var[1],'^{',get_stars(anova(mod1_intercept_only,mod1_no_intercept,test="Chisq")[2,8]),"}",sep=''),
                    paste(intercept_re_var[2],'^{',get_stars(anova(mod2_intercept_only,mod2_no_intercept,test="Chisq")[2,8]),"}",sep=''),
                    paste(intercept_re_var[2],'^{',get_stars(anova(mod3_intercept_only,mod3_no_intercept,test="Chisq")[2,8]),"}",sep=''),
                    paste(intercept_re_var[4],'^{',get_stars(anova(mod4_intercept_only,mod4_no_intercept,test="Chisq")[2,8]),"}",sep='')
)

pitch_re_var<-c(round(mod1_re[mod1_re$var1=="pitch_diff"&is.na(mod1_re$var2),'vcov'],2),round(mod2_re[mod2_re$var1=="pitch_diff"&is.na(mod2_re$var2),'vcov'],2),round(mod3_re[mod3_re$var1=="pitch_diff"&is.na(mod3_re$var2),'vcov'],2),round(mod4_re[mod4_re$var1=="pitch_diff"&is.na(mod4_re$var2),'vcov'],2))
pitch_re_sd<-c(round(mod1_re[mod1_re$var1=="pitch_diff"&is.na(mod1_re$var2),'sdcor'],2),round(mod2_re[mod2_re$var1=="pitch_diff"&is.na(mod2_re$var2),'sdcor'],2),round(mod3_re[mod3_re$var1=="pitch_diff"&is.na(mod3_re$var2),'sdcor'],2),round(mod4_re[mod4_re$var1=="pitch_diff"&is.na(mod4_re$var2),'sdcor'],2))

pitch_re_var<-c(paste(pitch_re_var[1],'^{',get_stars(anova(mod1,mod1_intercept_only,test="Chisq")[2,8]),"}",sep=''),
                paste(pitch_re_var[2],'^{',get_stars(anova(mod2,mod2_intercept_only,test="Chisq")[2,8]),"}",sep=''),
                paste(pitch_re_var[2],'^{',get_stars(anova(mod3,mod3_intercept_only,test="Chisq")[2,8]),"}",sep=''),
                paste(pitch_re_var[4],'^{',get_stars(anova(mod4,mod4_intercept_only,test="Chisq")[2,8]),"}",sep='')
)

stargazer(mod1,mod2,mod3,mod4,type='html',
          out='output/table_s3.html',
          intercept.bottom = FALSE,
          intercept.top = TRUE,
          omit.stat = c('bic'),
          dep.var.labels.include = FALSE,
          dep.var.caption = "",
          column.labels = c('no controls','dal','harvard','liwc'),
          add.lines = list(c("Random Effects", "", "", "", "", ""),
                           c("", "", "", "", "", ""),
                           c("Intercept",intercept_re_var),
                           c("",intercept_re_sd),
                           c("", "", "", "", "", ""),
                           c("Pitch Difference",pitch_re_var),
                           c("",pitch_re_sd),
                           c("", "", "", "", "", "")))


