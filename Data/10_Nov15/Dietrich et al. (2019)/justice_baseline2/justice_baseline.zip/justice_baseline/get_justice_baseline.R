####################################################################
# Description: Justice baseline example referenced on page 4 of SI #
# Author: Bryce J. Dietrich                                        #
# Affiliation: University of Iowa                                  #
# Date: 5/22/2018                                                  #
# Email: brycedietrich@gmail.com                                   #
# R Version: 3.4.3 (2017-11-30)                                    #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                     #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)              #
# Processor: 3 GHz Intel Core i7                                   #
# OS: macOS Sierra 10.12.6                                         #
# Data: 10-545_results.tab -> 10-704_results.tab                   #
# Packages: None                                                   #
# Output: example_justices.csv                                     #
#         example_justice_baseline.csv                             #
# Run Time: 0.252284 secs                                          #
####################################################################

setwd('/Users/brycedietrich/Dropbox/oral_arguments_base/replication/justice_baseline/')

#get list of folders...here I list them directly...you actually want to use list.files()
folder_lists<-c("10-545","10-553","10-577","10-637","10-680","10-694","10-699","10-704")
justice_dat<-rep(0,2)
for(i in 1:length(folder_lists)){
	print(i)
	#load transcript
	temp_transcript<-read.table(paste(folder_lists[i],"_results.tab",sep=""),header=TRUE,as.is=TRUE)
	temp_transcript<-temp_transcript[temp_transcript$stop_time-temp_transcript$start_time>1,]
	
	justice_ids<-unique(temp_transcript[temp_transcript$type=="justice","speaker_id"])
	for(j in 1:length(justice_ids)){
		justice_dat<-rbind(justice_dat,cbind(justice_ids[j],ifelse(length(temp_transcript[is.na(temp_transcript$pitch_mean)==FALSE&temp_transcript$speaker_id==justice_ids[j],"pitch_mean"])==0,NA,temp_transcript[is.na(temp_transcript$pitch_mean)==FALSE&temp_transcript$speaker_id==justice_ids[j],"pitch_mean"])))
	}
}
write.csv(justice_dat[-1,],"example_justices.csv",row.names=FALSE)

justices<-read.csv("example_justices.csv",as.is=TRUE)
names(justices)<-c("speaker_id","pitch_mean")
justices$speaker_id<-tolower(justices$speaker_id)
justices[justices$speaker_id%in%c("samuel_a_alito_jr","samuel_alito","samuel_alito_jr"),"speaker_id"]<-"samuel_alito"
justices[justices$speaker_id%in%c("anthony_kennedy","anthony_m_kennedy"),"speaker_id"]<-"anthony_kennedy"
justices[justices$speaker_id%in%c("john_g_roberts","john_g_roberts_jr"),"speaker_id"]<-"john_g_roberts"
justices[justices$speaker_id%in%c("william_j_brennan","william_j_brennan_jr"),"speaker_id"]<-"william_j_brennan"
justices[justices$speaker_id%in%c("lewis_f_powell","lewis_f_powell_jr"),"speaker_id"]<-"lewis_f_powell"
justice_ids<-unique(justices$speaker_id)

my_mean<-NULL
my_sd<-NULL
for(i in 1:length(justice_ids)){
	my_mean<-c(my_mean,mean(justices[tolower(justices$speaker_id)==justice_ids[i],"pitch_mean"],na.rm=TRUE))
	my_sd<-c(my_sd,sd(justices[tolower(justices$speaker_id)==justice_ids[i],"pitch_mean"],na.rm=TRUE))
}
justice_dat<-cbind(justice_ids,my_mean,my_sd)
colnames(justice_dat)<-c("speaker_id","pitch_mean","pitch_sd")

write.csv(justice_dat,"example_justice_baseline.csv",row.names=FALSE)