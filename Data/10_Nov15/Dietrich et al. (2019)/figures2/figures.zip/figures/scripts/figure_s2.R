###################################################################
# Description: Replicates Figure S2 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                       #
# Affiliation: University of Iowa                                 #
# Date: 6/7/2018                                                  #
# Email: brycedietrich@gmail.com                                  #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"               #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                    #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)             #
# Processor: 3 GHz Intel Core i7                                  #
# OS: macOS Sierra 10.12.6                                        #
# Data: praat_results.csv                                         #
# Packages: None                                                  #
# Output: figure_s2.png                                           #
# Run Time: 0.661469 secs                                         #
###################################################################

setwd('/Users/brycedietrich/Downloads/figures/')

###praat simulation
praat<-read.csv("data/praat_results.csv",as.is=TRUE)

png(filename="output/figure_s2.png", units = 'px', width=480, height=480)
par(mfrow=c(1,2))
#default values
plot(0,0,xlim=c(0,8),ylim=c(0,400),type="n",xaxt="n",xlab="",ylab="Fundamental Frequency (in Hz)", main="Default")

#men
true_mean1<-praat[praat$left==75&praat$right==600&praat$speaker==1,"mean_x"]
praat_mean1<-praat[praat$left==75&praat$right==600&praat$speaker==1,"mean_y"]

rect(1,0,2,true_mean1,col="lightgrey")
rect(2,0,3,praat_mean1,col="lightgrey")

rect(1,0,2,true_mean1)
rect(2,0,3,praat_mean1,density=5)

#women
true_mean2<-praat[praat$left==75&praat$right==600&praat$speaker==2,"mean_x"]
praat_mean2<-praat[praat$left==75&praat$right==600&praat$speaker==2,"mean_y"]

rect(5,0,6,true_mean2,col="lightgrey")
rect(6,0,7,praat_mean2,col="lightgrey")

rect(5,0,6,true_mean2)
rect(6,0,7,praat_mean2,density=5)

legend(.05,390,density=c(0,30),legend=c("True Mean","Praat Mean"),cex=.5)

text(c(2.5,7), par("usr")[3]-7,adj=1,labels=c("Men","Women"),xpd=T,cex=.7)

#recommended values
plot(0,0,xlim=c(0,8),ylim=c(0,400),type="n",xaxt="n",xlab="",ylab="Fundamental Frequency (in Hz)", main="Recommended")

#men
true_mean1<-praat[praat$left==75&praat$right==300&praat$speaker==1,"mean_x"]
praat_mean1<-praat[praat$left==75&praat$right==300&praat$speaker==1,"mean_y"]

rect(1,0,2,true_mean1,col="lightgrey")
rect(2,0,3,praat_mean1,col="lightgrey")

rect(1,0,2,true_mean1)
rect(2,0,3,praat_mean1,density=5)

#women
true_mean2<-praat[praat$left==100&praat$right==500&praat$speaker==2,"mean_x"]
praat_mean2<-praat[praat$left==100&praat$right==500&praat$speaker==2,"mean_y"]

rect(5,0,6,true_mean2,col="lightgrey")
rect(6,0,7,praat_mean2,col="lightgrey")

rect(5,0,6,true_mean2)
rect(6,0,7,praat_mean2,density=5)

legend(.05,390,density=c(0,30),legend=c("True Mean","Praat Mean"),cex=.5)

text(c(2.5,7), par("usr")[3]-7,adj=1,labels=c("Men","Women"),xpd=T,cex=.7)
dev.off()