###################################################################
# Description: Replicates Figure S3 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                       #
# Affiliation: University of Iowa                                 #
# Date: 6/7/2018                                                  #
# Email: brycedietrich@gmail.com                                  #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"               #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                    #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)             #
# Processor: 3 GHz Intel Core i7                                  #
# OS: macOS Sierra 10.12.6                                        #
# Data: boot_results.csv                                          #
# Packages: ggplot2_2.2.1                                         #
# Output: figure_s3.png                                           #
# Run Time: 1.551414 secs                                         #
###################################################################

require(ggplot2)

setwd('/Users/brycedietrich/Downloads/figures/')

boot_results<-read.csv('data/boot_results.csv',as.is=TRUE)

my_justices<-unique(boot_results$justiceName)
dat<-rep(0,4)
for(my_justice in my_justices){
  temp_p<-round(length(boot_results[boot_results$justiceName==my_justice,"slope"])*.025)
  high_p<-length(boot_results[boot_results$justiceName==my_justice,"slope"])-temp_p
  low_p<-temp_p
  dat<-rbind(dat,c(my_justice,median(boot_results[boot_results$justiceName==my_justice,"slope"]),sort(boot_results[boot_results$justiceName==my_justice,"slope"])[low_p],sort(boot_results[boot_results$justiceName==my_justice,"slope"])[high_p]))
}
dat<-dat[-1,]
colnames(dat)<-c('justiceName','median','ylo','yhi')
dat<-data.frame(dat,stringsAsFactors = FALSE)
dat$median<-as.numeric(dat$median)
dat$ylo<-as.numeric(dat$ylo)
dat$yhi<-as.numeric(dat$yhi)
boot_intervals<-rbind(dat[dat$justiceName=="CThomas",],
                      dat[dat$justiceName=="HABlackmun",],
                      dat[dat$justiceName=="LFPowell",],
                      dat[dat$justiceName=="BRWhite",],
                      dat[dat$justiceName=="TMarshall",],
                      dat[dat$justiceName=="WEBurger",],
                      dat[dat$justiceName=="EKagan",],
                      dat[dat$justiceName=="SAAlito",],
                      dat[dat$justiceName=="SSotomayor",],
                      dat[dat$justiceName=="SDOConnor",],
                      dat[dat$justiceName=="WHRehnquist",],
                      dat[dat$justiceName=="DHSouter",],
                      dat[dat$justiceName=="JPStevens",],
                      dat[dat$justiceName=="AMKennedy",],
                      dat[dat$justiceName=="JGRoberts",],
                      dat[dat$justiceName=="RBGinsburg",],
                      dat[dat$justiceName=="SGBreyer",],
                      dat[dat$justiceName=="AScalia",])

boot_intervals$justiceName2<-NA
boot_intervals[boot_intervals$justiceName=="AScalia",'justiceName2']<-"Scalia"
boot_intervals[boot_intervals$justiceName=="SGBreyer",'justiceName2']<-"Breyer"
boot_intervals[boot_intervals$justiceName=="RBGinsburg",'justiceName2']<-"Ginsburg"
boot_intervals[boot_intervals$justiceName=="JGRoberts",'justiceName2']<-"Roberts"
boot_intervals[boot_intervals$justiceName=="AMKennedy",'justiceName2']<-"Kennedy"
boot_intervals[boot_intervals$justiceName=="JPStevens",'justiceName2']<-"Stevens"
boot_intervals[boot_intervals$justiceName=="DHSouter",'justiceName2']<-"Souter"
boot_intervals[boot_intervals$justiceName=="WHRehnquist",'justiceName2']<-"Rehnquist"
boot_intervals[boot_intervals$justiceName=="SDOConnor",'justiceName2']<-"O'Connor"
boot_intervals[boot_intervals$justiceName=="SSotomayor",'justiceName2']<-"Sotomayor"
boot_intervals[boot_intervals$justiceName=="SAAlito",'justiceName2']<-"Alito"
boot_intervals[boot_intervals$justiceName=="EKagan",'justiceName2']<-"Kagan"
boot_intervals[boot_intervals$justiceName=="WEBurger",'justiceName2']<-"Burger"
boot_intervals[boot_intervals$justiceName=="TMarshall",'justiceName2']<-"Marshall"
boot_intervals[boot_intervals$justiceName=="BRWhite",'justiceName2']<-"White"
boot_intervals[boot_intervals$justiceName=="LFPowell",'justiceName2']<-"Powell"
boot_intervals[boot_intervals$justiceName=="HABlackmun",'justiceName2']<-"Blackmun"
boot_intervals[boot_intervals$justiceName=="CThomas",'justiceName2']<-"Thomas"
boot_intervals$justiceName2<-factor(boot_intervals$justiceName2, levels = boot_intervals$justiceName2)

png(filename="output/figure_s3.png", units = 'px', width=480, height=480)
p <- ggplot(boot_intervals, aes(x=justiceName2, y=median, ymin=ylo, ymax=yhi)) + 
     coord_flip() +
     theme_bw() +
     geom_pointrange(colour=ifelse(boot_intervals$ylo < 0 & boot_intervals$yhi > 0, "black", "black")) + 
     geom_hline(aes(yintercept=0),lty=2) +
     xlab('Justice') +
     ylab('')
p
dev.off()