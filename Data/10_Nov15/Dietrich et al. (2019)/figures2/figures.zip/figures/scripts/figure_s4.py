###################################################################
# Description: Replicates Figure S4 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                       #
# Affiliation: University of Iowa                                 #
# Date: 5/28/2018                                                 #
# Email: brycedietrich@gmail.com                                  #
# Pyton Version: 3.6.3 (default, Oct  4 2017, 06:09:15)           #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                    #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)             #
# Processor: 3 GHz Intel Core i7                                  #
# OS: macOS Sierra 10.12.6                                        #
# Data: justice_predictions.csv                                   #
#       justice_photos (folder)                                   #
# Modules: pandas (0.23.0)                                        #
#          matplotlib (2.2.2)                                     #
#          numpy (1.14.3)                                         #
#          scipy (1.1.0)                                          #
# Output: figure_s4.png                                           #
# Run Time: 22.940905 secs                                        #
###################################################################

import pandas as pd
import matplotlib
matplotlib.use('TKAgg')

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from numpy import *
from scipy.stats import sem
from matplotlib.font_manager import FontProperties
from matplotlib._png import read_png
from matplotlib.cbook import get_sample_data
from matplotlib.offsetbox import OffsetImage, AnnotationBbox

# set wd
wd = "/Users/brycedietrich/Downloads/figures/"

# load data
data = pd.read_csv(wd + "data/justice_predictions.csv", encoding='utf8')
names = data.justiceName

# create intial plot...group subplots together
f, ((scalia, ginsburg, breyer),
    (kennedy, stevens, souter)) = plt.subplots(2, 3, sharex=True, sharey=True)

# add photos
# scalia photo
scalia_png = get_sample_data(wd + "data/justice_photos/scalia.png",
                             asfileobj=False)

scalia_lena = read_png(scalia_png)
scaliabox = OffsetImage(scalia_lena, zoom=0.025, filterrad=4.0)
scalia_photo = AnnotationBbox(scaliabox, (.717, .755),
                              xybox=(0., 0.),
                              xycoords='data',
                              boxcoords="offset points",
                              pad=0,
                              )

# kennedy photo
kennedy_png = get_sample_data(wd + "data/justice_photos/kennedy.png",
                              asfileobj=False)

kennedy_lena = read_png(kennedy_png)
kennedybox = OffsetImage(kennedy_lena, zoom=0.0833333, filterrad=4.0)
kennedy_photo = AnnotationBbox(kennedybox, (.70, .755),
                               xybox=(0., 0.),
                               xycoords='data',
                               boxcoords="offset points",
                               pad=0,
                               )
# breyer photo
breyer_png = get_sample_data(wd + "data/justice_photos/breyer.png",
                             asfileobj=False)

breyer_lena = read_png(breyer_png)
breyerbox = OffsetImage(breyer_lena, zoom=0.1333333, filterrad=4.0)
breyer_photo = AnnotationBbox(breyerbox, (.725, .755),
                              xybox=(0., 0.),
                              xycoords='data',
                              boxcoords="offset points",
                              pad=0,
                              )

# ginsburg photo
ginsburg_png = get_sample_data(wd + "data/justice_photos/ginsburg.png",
                               asfileobj=False)

ginsburg_lena = read_png(ginsburg_png)
ginsburgbox = OffsetImage(ginsburg_lena, zoom=0.1125, filterrad=4.0)
ginsburg_photo = AnnotationBbox(ginsburgbox, (.63, .755),
                                xybox=(0., 0.),
                                xycoords='data',
                                boxcoords="offset points",
                                pad=0,
                                )

# ginsburg photo
stevens_png = get_sample_data(wd + "data/justice_photos/stevens.png",
                              asfileobj=False)

stevens_lena = read_png(stevens_png)
stevensbox = OffsetImage(stevens_lena, zoom=0.03416668, filterrad=4.0)
stevens_photo = AnnotationBbox(stevensbox, (.73, .754),
                               xybox=(0., 0.),
                               xycoords='data',
                               boxcoords="offset points",
                               pad=0,
                               )
# souter photo
souter_png = get_sample_data(wd + "data/justice_photos/souter.png",
                             asfileobj=False)

souter_lena = read_png(souter_png)
souterbox = OffsetImage(souter_lena, zoom=0.0625, filterrad=4.0)
souter_photo = AnnotationBbox(souterbox, (.71, .755),
                              xybox=(0., 0.),
                              xycoords='data',
                              boxcoords="offset points",
                              pad=0
                              )

# set fonts
tick_font = {'fontname': 'Arial', 'fontsize': 10}
small_font = {'fontname': 'Arial', 'fontsize': 8}

# set labels
x_labels = ['-1', '0.50', '0', '0.50', '1']
y_labels = ['0.30', '0.40', '0.50', '0.60', '0.70', '0.80']

plt.setp(ginsburg.set_xticks([-1, -0.5, 0, 0.5, 1]))
plt.setp(scalia.set_xticks([-1, -0.5, 0, 0.5, 1]))
plt.setp(breyer.set_xticks([-1, -0.5, 0, 0.5, 1]))
plt.setp(kennedy.set_xticks([-1, -0.5, 0, 0.5, 1]))
plt.setp(stevens.set_xticks([-1, -0.5, 0, 0.5, 1]))
plt.setp(souter.set_xticks([-1, -0.5, 0, 0.5, 1]))

plt.setp(scalia.set_yticklabels(y_labels, **tick_font))
plt.setp(kennedy.set_xticklabels(x_labels, **tick_font))
plt.setp(kennedy.set_yticklabels(y_labels, **tick_font))
plt.setp(stevens.set_xticklabels(x_labels, **tick_font))
plt.setp(souter.set_xticklabels(x_labels, **tick_font))

# ginsburg
ginsburg.set_xlim([-1.15, 1.15])
ginsburg.plot(data[names == "RBGinsburg"].pitch,
              data[names == "RBGinsburg"].vote,
              color="blue",
              lw=2)

ginsburg.fill_between(data[names == "RBGinsburg"].pitch,
                      data[names == "RBGinsburg"].lower_vote,
                      data[names == "RBGinsburg"].upper_vote,
                      color='blue',
                      alpha=0.1697868)

ginsburg.add_artist(ginsburg_photo)
ginsburg.text(0.44, 0.635, "Ruth", **small_font)
ginsburg.text(0.4004762, 0.595, "Bader", **small_font)
ginsburg.text(0.29, 0.555, "Ginsburg", **small_font)

# scalia
scalia.set_xlim([-1.15, 1.15])
scalia.set_ylim([0.30, 0.85])
scalia.plot(data[names == "AScalia"].pitch,
            data[names == "AScalia"].vote,
            color="red",
            lw=2)

scalia.fill_between(data[names == "AScalia"].pitch,
                    data[names == "AScalia"].lower_vote,
                    data[names == "AScalia"].upper_vote,
                    color='red',
                    alpha=0.30)


scalia.add_artist(scalia_photo)
scalia.text(.447, 0.64, "Antonin", **small_font)
scalia.text(.487, 0.60, "Scalia", **small_font)

# breyer
breyer.set_xlim([-1.15, 1.15])
breyer.plot(data[names == "SGBreyer"].pitch,
            data[names == "SGBreyer"].vote,
            color="blue",
            lw=2)

breyer.fill_between(data[names == "SGBreyer"].pitch,
                    data[names == "SGBreyer"].lower_vote,
                    data[names == "SGBreyer"].upper_vote,
                    color='blue',
                    alpha=0.2121878)

breyer.add_artist(breyer_photo)
breyer.text(0.38, 0.64, "Stephen", **small_font)
breyer.text(0.45, 0.60, "Breyer", **small_font)

# kennedy
kennedy.set_xlim([-1.15, 1.15])
kennedy.plot(data[names == "AMKennedy"].pitch,
             data[names == "AMKennedy"].vote,
             color="red",
             lw=2)

kennedy.fill_between(data[names == "AMKennedy"].pitch,
                     data[names == "AMKennedy"].lower_vote,
                     data[names == "AMKennedy"].upper_vote,
                     color='red',
                     alpha=0.1440495)

kennedy.add_artist(kennedy_photo)
kennedy.text(0.37, 0.64, "Anthony", **small_font)
kennedy.text(0.34, 0.60, "Kennedy", **small_font)

# stevens
stevens.set_xlim([-1.15, 1.15])
stevens.plot(data[names == "JPStevens"].pitch,
             data[names == "JPStevens"].vote,
             color="red",
             lw=2)

stevens.fill_between(data[names == "JPStevens"].pitch,
                     data[names == "JPStevens"].lower_vote,
                     data[names == "JPStevens"].upper_vote,
                     color='red',
                     alpha=0.1207526)

stevens.add_artist(stevens_photo)
stevens.text(0.51, .64, "John", **small_font)
stevens.text(0.53, .60, "Paul", **small_font)
stevens.text(0.38, .56, "Stevens", **small_font)

# souter
souter.set_xlim([-1.15, 1.15])
souter.plot(data[names == "DHSouter"].pitch,
            data[names == "DHSouter"].vote,
            color="red",
            lw=2)

souter.fill_between(data[names == "DHSouter"].pitch,
                    data[names == "DHSouter"].lower_vote,
                    data[names == "DHSouter"].upper_vote,
                    color='red',
                    alpha=0.1206235)

souter.add_artist(souter_photo)
souter.text(0.48, 0.64, "David", **small_font)
souter.text(0.44, 0.60, "Souter", **small_font)

# save the figure as high quality png
f.subplots_adjust(wspace=0.20, hspace=0.05)
plt.savefig(wd + 'output/figure_s4.png', format='png',
            dpi=1200,  bbox_inches='tight')
