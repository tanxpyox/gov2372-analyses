###################################################################
# Description: Replicates Figure S5 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                       #
# Affiliation: University of Iowa                                 #
# Date: 6/7/2018                                                  #
# Email: brycedietrich@gmail.com                                  #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"               #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                    #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)             #
# Processor: 3 GHz Intel Core i7                                  #
# OS: macOS Sierra 10.12.6                                        #
# Data: travel_ban.csv                                            #
# Packages: ggplot2_2.2.1                                         #
# Output: figure_s5.png                                           #
# Run Time: 1.072305 secs                                         #
###################################################################

require(ggplot2)

setwd('/Users/brycedietrich/Downloads/figures/')

trump<-read.csv('data/travel_ban.csv',as.is=TRUE)

###overall
trump$f1f2 <- interaction(trump$judge,trump$lawyer)
trump$f1f2_order<-"a"
trump[trump$f1f2=="judge2.trump","f1f2_order"]<-"a"
trump[trump$f1f2=="judge2.wash","f1f2_order"]<-"b"
trump[trump$f1f2=="judge3.trump","f1f2_order"]<-"c"
trump[trump$f1f2=="judge3.wash","f1f2_order"]<-"d"
trump[trump$f1f2=="judge1.trump","f1f2_order"]<-"e"
trump[trump$f1f2=="judge1.wash","f1f2_order"]<-"f"

png(filename="output/figure_s5.png", units = 'px', width=480, height=480)
p<-ggplot(aes(y = pitch_mean, x = f1f2_order, fill=f1f2_order), data = trump) + 
  geom_boxplot(outlier.shape = NA,lwd=1) + 
  scale_fill_manual(name="Lawyer",values=c("darkgrey","white","darkgrey","white","darkgrey","white"),labels=c("a"="Trump","c"="Trump","e"="Trump","b"="Washington","d"="Washington","f"="Washignton")) +
  scale_x_discrete(labels=c("a"="Judge \n Canby","b"="Judge \n Canby","c"="Judge \n Clifton","d"="Judge \n Clifton", "e"="Judge \n Friedland", "f"="Judge \n Friedland")) +
  labs(y = "Mean Vocal Pitch",x = "") +
  theme_bw()
p<-p+theme(legend.position="none",axis.text.x = element_text(angle = 60, hjust = 1))
p
dev.off()