###################################################################
# Description: Replicates Figure S7 in Dietrich, Enos, Sen (2018) #
# Author: Bryce J. Dietrich                                       #
# Affiliation: University of Iowa                                 #
# Date: 6/7/2018                                                  #
# Email: brycedietrich@gmail.com                                  #
# R Version: 3.5.0 (2018-04-23) -- "Joy in Playing"               #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                    #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)             #
# Processor: 3 GHz Intel Core i7                                  #
# OS: macOS Sierra 10.12.6                                        #
# Data: justice_results.tab                                       #
#       EmoJusticeRep.dta                                         #
# Packages: foreign_0.8-70                                        #
#           ggplot2_2.2.1                                         #
#           lme4_1.1-17                                           #
#           Matrix_1.2-14                                         #
# Output: figure_s7.png                                           #
# Run Time: 10.24934 secs                                         #
###################################################################

require(foreign)
require(ggplot2)
require(lme4)

setwd('/Users/brycedietrich/Downloads/figures/')

#load justice_results
sc<-read.table("data/justice_results.tab",header=TRUE,as.is=TRUE,sep="\t")

#load black et al. results
black<-read.dta("data/EmoJusticeRep.dta")
black$petitioner_vote<-black$petVote

#function to extract prediction statistics
get_stats<-function(my_model,my_data){
  my_data<-my_data[names(residuals(my_model)),]
  base_matrix<-table(ifelse(predict(my_model,type="response",re.form=NA)>.50,"Test_Yes","Test_No"),ifelse(my_data[,"petitioner_vote"]==1,"Actual_Yes","Actual_No"))
  results_matrix<-matrix(0,2,2)
  rownames(results_matrix)<-c("Test_Yes","Test_No")
  colnames(results_matrix)<-c("Actual_Yes","Actual_No")
  results_matrix["Test_Yes","Actual_Yes"]<-base_matrix["Test_Yes","Actual_Yes"]
  results_matrix["Test_Yes","Actual_No"]<-base_matrix["Test_Yes","Actual_No"]
  results_matrix["Test_No","Actual_Yes"]<-base_matrix["Test_No","Actual_Yes"]
  results_matrix["Test_No","Actual_No"]<-base_matrix["Test_No","Actual_No"]
  tpr<-results_matrix["Test_Yes","Actual_Yes"]/(results_matrix["Test_Yes","Actual_Yes"]+results_matrix["Test_No","Actual_Yes"])
  fpr<-results_matrix["Test_Yes","Actual_No"]/(results_matrix["Test_Yes","Actual_No"]+results_matrix["Test_No","Actual_No"])
  fnr<-1-tpr
  tnr<-1-fpr
  return(list(my_tpr=round(tpr,2),my_fpr=round(fpr,2),my_fnr=round(fnr,2),my_tnr=round(tnr,2)))
}

#labels for ggplot2
my_labels<-c("% More Unpleasant Words Directed at Petitioner",
             "% More Pleasant Words Directed at Petitioner",
             "# More Questions Directed at Petitioner",
             "Lagged Ideology",
             "LC Decision Was Conservative",
             "Lagged Ideology x LC Decision Was Conservative",
             "Solicitor General as Amicus Supporting Petitioner",
             "Solicitor General as Amicus Supporting Respondent",
             "# of Amicus Briefs Supporting Petitioner",
             "# of Amicus Briefs Supporting Respondent",
             "Petitioner's Level of Resources",
             "Respondents's Level of Resources")

#our data
sc$petitioner_neg_words<-sc$petitioner_dal_neg
sc$respondent_neg_words<-sc$respondent_dal_neg
sc$petitioner_pos_words<-sc$petitioner_dal_neg
sc$respondent_pos_words<-sc$respondent_dal_neg
modA<-glmer(petitioner_vote~I((petitioner_neg_words/petitioner_wc) - (respondent_neg_words/respondent_wc))+(1|justiceName),data=sc,family=binomial)
modB<-glmer(petitioner_vote~I((petitioner_pos_words/petitioner_wc) - (respondent_pos_words/respondent_wc))+(1|justiceName),data=sc,family=binomial)
modC<-glmer(petitioner_vote~I(petitioner_count - respondent_count)+(1|justiceName),data=sc,family=binomial)
modD<-glmer(petitioner_vote~lagged_ideology+(1|justiceName),data=sc,family=binomial)
modE<-glmer(petitioner_vote~conservative_lc+(1|justiceName),data=sc,family=binomial)
modF<-glmer(petitioner_vote~I(lagged_ideology * conservative_lc)+(1|justiceName),data=sc,family=binomial)
modG<-glmer(petitioner_vote~sgpetac+(1|justiceName),data=sc,family=binomial)
modH<-glmer(petitioner_vote~sgrespac+(1|justiceName),data=sc,family=binomial)
modI<-glmer(petitioner_vote~petac+(1|justiceName),data=sc,family=binomial)
modJ<-glmer(petitioner_vote~respac+(1|justiceName),data=sc,family=binomial)
modK<-glmer(petitioner_vote~petNumStat+(1|justiceName),data=sc,family=binomial)
modL<-glmer(petitioner_vote~respNumStat+(1|justiceName),data=sc,family=binomial)

my_TPR<-c(get_stats(modA,sc)$my_tpr,get_stats(modB,sc)$my_tpr,get_stats(modC,sc)$my_tpr,get_stats(modD,sc)$my_tpr,get_stats(modB,sc)$my_tpr,get_stats(modF,sc)$my_tpr,get_stats(modB,sc)$my_tpr,get_stats(modH,sc)$my_tpr,get_stats(modB,sc)$my_tpr,get_stats(modJ,sc)$my_tpr,get_stats(modK,sc)$my_tpr,get_stats(modB,sc)$my_tpr)
my_FPR<-c(get_stats(modA,sc)$my_fpr,get_stats(modB,sc)$my_fpr,get_stats(modC,sc)$my_fpr,get_stats(modD,sc)$my_fpr,get_stats(modB,sc)$my_fpr,get_stats(modF,sc)$my_fpr,get_stats(modB,sc)$my_fpr,get_stats(modH,sc)$my_fpr,get_stats(modB,sc)$my_fpr,get_stats(modJ,sc)$my_fpr,get_stats(modK,sc)$my_fpr,get_stats(modB,sc)$my_fpr)
my_FNR<-c(get_stats(modA,sc)$my_fnr,get_stats(modB,sc)$my_fnr,get_stats(modC,sc)$my_fnr,get_stats(modD,sc)$my_fnr,get_stats(modB,sc)$my_fnr,get_stats(modF,sc)$my_fnr,get_stats(modB,sc)$my_fnr,get_stats(modH,sc)$my_fnr,get_stats(modB,sc)$my_fnr,get_stats(modJ,sc)$my_fnr,get_stats(modK,sc)$my_fnr,get_stats(modB,sc)$my_fnr)
my_TNR<-c(get_stats(modA,sc)$my_tnr,get_stats(modB,sc)$my_tnr,get_stats(modC,sc)$my_tnr,get_stats(modD,sc)$my_tnr,get_stats(modB,sc)$my_tnr,get_stats(modF,sc)$my_tnr,get_stats(modB,sc)$my_tnr,get_stats(modH,sc)$my_tnr,get_stats(modB,sc)$my_tnr,get_stats(modJ,sc)$my_tnr,get_stats(modK,sc)$my_tnr,get_stats(modB,sc)$my_tnr)

dat<-data.frame(rbind(cbind(my_labels,my_TPR,"True Positive Rate"),cbind(my_labels,my_FPR,"False Positive Rate"),cbind(my_labels,my_FNR,"False Negative Rate"),cbind(my_labels,my_TNR,"True Negative Rate")))
names(dat)<-c("label","percent","rate")
dat$percent<-as.numeric(as.character(dat$percent))
dat$origin<-'b_our_data'

##their data
modA<-glmer(petitioner_vote~unpleasantDiff_totalWords+(1|justiceName),data=black,family=binomial)
modB<-glmer(petitioner_vote~pleasantDiff_totalWords+(1|justiceName),data=black,family=binomial)
modC<-glmer(petitioner_vote~questionDifference+(1|justiceName),data=black,family=binomial)
modD<-glmer(petitioner_vote~justiceMQ+(1|justiceName),data=black,family=binomial)
modE<-glmer(petitioner_vote~lowerConservative+(1|justiceName),data=black,family=binomial)
modF<-glmer(petitioner_vote~lowerConXjusticeMQ+(1|justiceName),data=black,family=binomial)
modG<-glmer(petitioner_vote~sgpetac+(1|justiceName),data=black,family=binomial)
modH<-glmer(petitioner_vote~sgrespac+(1|justiceName),data=black,family=binomial)
modI<-glmer(petitioner_vote~petac+(1|justiceName),data=black,family=binomial)
modJ<-glmer(petitioner_vote~respac+(1|justiceName),data=black,family=binomial)
modK<-glmer(petitioner_vote~petNumStat+(1|justiceName),data=black,family=binomial)
modL<-glmer(petitioner_vote~respNumStat+(1|justiceName),data=black,family=binomial)

my_TPR<-c(get_stats(modA,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modC,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modF,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modH,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modB,black)$my_tpr,get_stats(modB,black)$my_tpr)
my_FPR<-c(get_stats(modA,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modC,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modF,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modH,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modB,black)$my_fpr,get_stats(modB,black)$my_fpr)
my_FNR<-c(get_stats(modA,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modC,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modF,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modH,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modB,black)$my_fnr,get_stats(modB,black)$my_fnr)
my_TNR<-c(get_stats(modA,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modC,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modF,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modH,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modB,black)$my_tnr,get_stats(modB,black)$my_tnr)

dat2<-data.frame(rbind(cbind(my_labels,my_TPR,"True Positive Rate"),cbind(my_labels,my_FPR,"False Positive Rate"),cbind(my_labels,my_FNR,"False Negative Rate"),cbind(my_labels,my_TNR,"True Negative Rate")))
names(dat2)<-c("label","percent","rate")
dat2$percent<-as.numeric(as.character(dat2$percent))
dat2$origin<-'a_their_data'

#combine results
dat3<-rbind(dat,dat2)

#Figure S7: Black et al. (2011) False Positive Rate
png(filename="output/figure_s7.png", units = 'px', width=480, height=480)
p<-ggplot(data=dat3[dat3$rate=="False Positive Rate",], aes(x=label,y=percent,fill=origin)) + geom_bar(stat="identity",position=position_dodge())+geom_hline(aes(yintercept = .83),color="red")+coord_flip()+xlab("")+ylim(0,1)+ylab("Percent")+scale_fill_manual(values=c("grey", "black"),breaks=c("Our Data", "Author Data"))+theme(panel.background = element_rect(fill = 'white'),panel.grid.major = element_line(colour = "lightgrey"),axis.ticks=element_line(colour = "lightgrey"),legend.position="none")
p
dev.off()