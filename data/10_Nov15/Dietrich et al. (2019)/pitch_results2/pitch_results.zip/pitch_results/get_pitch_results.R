##################################################################
# Description: Pitch Results Example Reference on Page 4-5 in SI #
# Author: Bryce J. Dietrich                                      #
# Affiliation: University of Iowa                                #
# Date: 5/22/2018                                                #
# Email: brycedietrich@gmail.com                                 #
# R Version: 3.4.3 (2017-11-30)                                  #
# Platform: x86_64-apple-darwin15.6.0 (64-bit)                   #
# Computer: MacBook Pro (Retina, 13-inch, Early 2013)            #
# Processor: 3 GHz Intel Core i7                                 #
# OS: macOS Sierra 10.12.6                                       #
# Data: 10-545_results.tab -> 10-704_results.tab                 #
#       dal.tab                                                  #
#       full_justice_baseline.tab                                #
#       harvard.tab                                              #
# Packages: quanteda_0.99.22                                     #
# Output: example_justice_results.csv                            #
# Run Time: 1.160631 mins                                        #
##################################################################

require(quanteda)

setwd('/Users/brycedietrich/Downloads/dataverse_files/pitch_results/')

#read dictionaries...for this demonstration we only include dal and harvard
dal<-read.table("dal.tab",header=TRUE,as.is=TRUE)
harvard<-read.table("harvard.tab",header=TRUE,as.is=TRUE)

#load baseline...for this demonstration we use the actual justice baseline we used
justices<-read.table("full_justice_baseline.tab",header=TRUE,as.is=TRUE)

#get file list
folder_lists<-c("10-545","10-553","10-577","10-637","10-680","10-694","10-699","10-704")

#loop through files
final_dat<-matrix(0,1,12)
for(i in 1:length(folder_lists)){
  print(i)
  
  #load transcript
  temp_transcript<-read.table(paste(folder_lists[i],"_results.tab",sep=""),header=TRUE,as.is=TRUE)
  temp_transcript<-temp_transcript[order(temp_transcript$start_time),]
  
  #restrict transcript to utterances greater than 1 second
  temp_transcript<-temp_transcript[temp_transcript$stop_time-temp_transcript$start_time>1,]
  
  #loop through transcript
  for(j in 1:NROW(temp_transcript)){
    
    #if row has pitch and text has quesiton mark use
    if(is.na(temp_transcript[j,"pitch_mean"])==FALSE&grepl("[?]",temp_transcript[j,"text"])==TRUE){
      
      #if row has a justice speaking use
      if(temp_transcript[j,"type"]%in%c("justice")){
        
        #get the baseline for the justice
        temp_mean<-justices[justices$speaker_id==tolower(temp_transcript[j,"speaker_id"]),"pitch_mean"]
        temp_sd<-justices[justices$speaker_id==tolower(temp_transcript[j,"speaker_id"]),"pitch_sd"]
        
        #determine whether there is an advocate speaking somewhere between the next row and the end of the transcript
        if(length(c(1:length(seq(j+1,NROW(temp_transcript))))[temp_transcript[seq(j+1,NROW(temp_transcript)),"type"]=="advocate"])>0){
          
          #record the number of rows ahead the advocate appears
          my_add<-suppressWarnings(min(c(1:length(seq(j+1,NROW(temp_transcript))))[temp_transcript[seq(j+1,NROW(temp_transcript)),"type"]=="advocate"]))
          
          #if an advocate appears ahead continue
          if(length(my_add)>0){
            
            #if the advocate's role is "respondent" use the following code...same as petitioner but for the "respondent" record
            if(grepl("respondent",tolower(temp_transcript[j+my_add,"advocate_role"]))){
              
              #word count
              temp_wc<-length(unlist(strsplit(temp_transcript[j,"text"]," ")))
              
              #dal
              temp_dfm<-dfm(temp_transcript[j,"text"],dictionary=dictionary(list(dal_pos=dal[dal$valence=="positive","word"],dal_neg=dal[dal$valence=="negative","word"])),verbose=FALSE)
              temp_dal_pos<-as.numeric(temp_dfm[1,1])[1]
              temp_dal_neg<-as.numeric(temp_dfm[1,2])[1]
              
              #harvard
              temp_dfm<-dfm(temp_transcript[j,"text"],dictionary=dictionary(list(harvard_pos=harvard[harvard$valence=="positive","word"],harvard_neg=harvard[harvard$valence=="negative","word"])),verbose=FALSE)
              temp_harvard_pos<-as.numeric(temp_dfm[1,1])[1]
              temp_harvard_neg<-as.numeric(temp_dfm[1,2])[1]
              
              #advocate information
              advocate_id<-temp_transcript[j+my_add,"speaker_id"]
              advocate_mean<-mean(temp_transcript[temp_transcript$speaker_id==advocate_id,"pitch_mean"],na.rm=TRUE)
              advocate_sd<-sd(temp_transcript[temp_transcript$speaker_id==advocate_id,"pitch_mean"],na.rm=TRUE)
              
              if(length(c(folder_lists[i],temp_transcript[j,"speaker_id"],"respondent",(temp_transcript[j,"pitch_mean"]-temp_mean)/temp_sd,(temp_transcript[j+my_add,"pitch_mean"]-advocate_mean)/advocate_sd,temp_transcript[j+my_add,"gender"],temp_transcript[j,"gender"],temp_wc,temp_dal_pos,temp_dal_neg,temp_harvard_pos,temp_harvard_neg))==NCOL(final_dat)){
                final_dat<-rbind(final_dat,c(folder_lists[i],temp_transcript[j,"speaker_id"],"respondent",(temp_transcript[j,"pitch_mean"]-temp_mean)/temp_sd,(temp_transcript[j+my_add,"pitch_mean"]-advocate_mean)/advocate_sd,temp_transcript[j+my_add,"gender"],temp_transcript[j,"gender"],temp_wc,temp_dal_pos,temp_dal_neg,temp_harvard_pos,temp_harvard_neg))	
              }
            }
            
            #if the advocate's role is "petitioner" use the following code...same as respondent but for the "petitioner" record
            if(grepl("petitioner",tolower(temp_transcript[j+my_add,"advocate_role"]))){
              
              #word count
              temp_wc<-length(unlist(strsplit(temp_transcript[j,"text"]," ")))
              
              #dal
              temp_dfm<-dfm(temp_transcript[j,"text"],dictionary=dictionary(list(dal_pos=dal[dal$valence=="positive","word"],dal_neg=dal[dal$valence=="negative","word"])),verbose=FALSE)
              temp_dal_pos<-as.numeric(temp_dfm[1,1])[1]
              temp_dal_neg<-as.numeric(temp_dfm[1,2])[1]
              
              #harvard
              temp_dfm<-dfm(temp_transcript[j,"text"],dictionary=dictionary(list(harvard_pos=harvard[harvard$valence=="positive","word"],harvard_neg=harvard[harvard$valence=="negative","word"])),verbose=FALSE)
              temp_harvard_pos<-as.numeric(temp_dfm[1,1])[1]
              temp_harvard_neg<-as.numeric(temp_dfm[1,2])[1]
              
              #advocate information
              advocate_id<-temp_transcript[j+my_add,"speaker_id"]
              advocate_mean<-mean(temp_transcript[temp_transcript$speaker_id==advocate_id,"pitch_mean"],na.rm=TRUE)
              advocate_sd<-sd(temp_transcript[temp_transcript$speaker_id==advocate_id,"pitch_mean"],na.rm=TRUE)
              
              if(length(c(folder_lists[i],temp_transcript[j,"speaker_id"],"petitioner",(temp_transcript[j,"pitch_mean"]-temp_mean)/temp_sd,(temp_transcript[j+my_add,"pitch_mean"]-advocate_mean)/advocate_sd,temp_transcript[j+my_add,"gender"],temp_transcript[j,"gender"],temp_wc,temp_dal_pos,temp_dal_neg,temp_harvard_pos,temp_harvard_neg))==NCOL(final_dat)){
                final_dat<-rbind(final_dat,c(folder_lists[i],temp_transcript[j,"speaker_id"],"petitioner",(temp_transcript[j,"pitch_mean"]-temp_mean)/temp_sd,(temp_transcript[j+my_add,"pitch_mean"]-advocate_mean)/advocate_sd,temp_transcript[j+my_add,"gender"],temp_transcript[j,"gender"],temp_wc,temp_dal_pos,temp_dal_neg,temp_harvard_pos,temp_harvard_neg))	
              }
            }
          }	
        }
      }
    }
  }
}
colnames(final_dat)<-c("file_name","speaker_id","question_direction","justice_pitch","advocate_pitch","advocate_gender","justice_gender","justice_wc","justice_dal_pos","justice_dal_neg","justice_harvard_pos","justice_harvard_neg")
write.csv(final_dat[-1,],"example_justice_results.csv",row.names=FALSE)